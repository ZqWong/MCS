-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: vrexaminationmaincontrolsystemdb
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_examination_child_subject_info`
--

DROP TABLE IF EXISTS `t_examination_child_subject_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_child_subject_info` (
  `ExaminationChildSubjectID` int(11) NOT NULL AUTO_INCREMENT COMMENT '考试子科目编号',
  `ExaminationChildSubjectName` varchar(100) DEFAULT NULL COMMENT '考试子科目名称',
  `ExaminationChildSubjectShortName` varchar(4) DEFAULT NULL COMMENT '考试子科目简称',
  `ExaminationSubjectID` int(11) DEFAULT NULL COMMENT '考试科目编号',
  PRIMARY KEY (`ExaminationChildSubjectID`),
  KEY `FK_ExaminationSubjectID_idx` (`ExaminationSubjectID`),
  CONSTRAINT `FK_ExaminationSubjectID` FOREIGN KEY (`ExaminationSubjectID`) REFERENCES `t_examination_subject_info` (`ExaminationSubjectID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='考试子科目信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_child_subject_info`
--

LOCK TABLES `t_examination_child_subject_info` WRITE;
/*!40000 ALTER TABLE `t_examination_child_subject_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_examination_child_subject_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examination_info`
--

DROP TABLE IF EXISTS `t_examination_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_info` (
  `ExaminationID` int(11) NOT NULL AUTO_INCREMENT COMMENT '考试编号',
  `ExaminationName` varchar(100) DEFAULT NULL COMMENT '考试名称',
  `PaperCompilingMode` varchar(100) DEFAULT NULL COMMENT '组卷方式',
  `TotalScore` int(11) DEFAULT NULL COMMENT '总分',
  `ExaminationPassScore` int(11) DEFAULT NULL COMMENT '合格',
  `ExaminationTime` int(11) DEFAULT NULL COMMENT '考试时间（分钟）',
  PRIMARY KEY (`ExaminationID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='考试信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_info`
--

LOCK TABLES `t_examination_info` WRITE;
/*!40000 ALTER TABLE `t_examination_info` DISABLE KEYS */;
INSERT INTO `t_examination_info` VALUES (1,'煤矿采煤机操作作业安全技术实际操作考试','由 K1、 K2 两个科目组成试卷。',100,80,30),(2,'煤矿掘进机操作作业安全技术实际操作考试','由 K1、 K2 两个科目组成试卷。',100,80,30);
/*!40000 ALTER TABLE `t_examination_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examination_pc_info`
--

DROP TABLE IF EXISTS `t_examination_pc_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_pc_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ExamPCName` varchar(45) DEFAULT NULL,
  `IP` varchar(45) DEFAULT NULL,
  `Port` varchar(45) DEFAULT NULL,
  `Mac` varchar(45) DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL COMMENT '类型：考试机1、练习机0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='考试机信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_pc_info`
--

LOCK TABLES `t_examination_pc_info` WRITE;
/*!40000 ALTER TABLE `t_examination_pc_info` DISABLE KEYS */;
INSERT INTO `t_examination_pc_info` VALUES (13,'1号考试机','192.168.1.101',NULL,'10-E7-C6-16-30-0A','1'),(14,'2号考试机','192.168.1.102',NULL,'10-E7-C6-13-EC-11','1'),(15,'3号考试机','192.168.1.103',NULL,'10-E7-C6-16-2F-DA','1'),(16,'4号练习机','192.168.1.104',NULL,'10-E7-C6-13-EC-78','0'),(17,'5号练习机','192.168.1.105',NULL,'10-E7-C6-13-27-D4','0'),(18,'6号练习机','192.168.1.106',NULL,'10-E7-C6-16-2F-F3','0'),(19,'7号练习机','192.168.1.107',NULL,'10-E7-C6-16-2F-96','0'),(20,'8号练习机','192.168.1.108',NULL,'10-E7-C6-13-EB-A8','0'),(21,'9号练习机','192.168.1.109',NULL,'10-E7-C6-16-2F-C6','0');
/*!40000 ALTER TABLE `t_examination_pc_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examination_result_detail_info`
--

DROP TABLE IF EXISTS `t_examination_result_detail_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_result_detail_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ExaminationResultID` int(11) DEFAULT NULL,
  `ExaminationSubjectID` int(11) DEFAULT NULL COMMENT '考试科目',
  `No` int(11) DEFAULT NULL COMMENT '序号',
  `ExaminationItem` varchar(20) DEFAULT NULL COMMENT '考试项目',
  `ExaminationContentAndStep_Title` varchar(20) DEFAULT NULL,
  `ExaminationContentAndStep_Detail` varchar(45) DEFAULT NULL,
  `ScoreValue` int(11) DEFAULT NULL COMMENT '分值',
  `EvaluationStandard` varchar(45) DEFAULT NULL COMMENT '评分标准',
  `DeductionCondition` varchar(45) DEFAULT NULL COMMENT '扣分情况',
  `DeductionReason` varchar(200) DEFAULT NULL COMMENT '扣分原因',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COMMENT='考试结果详情信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_result_detail_info`
--

LOCK TABLES `t_examination_result_detail_info` WRITE;
/*!40000 ALTER TABLE `t_examination_result_detail_info` DISABLE KEYS */;
INSERT INTO `t_examination_result_detail_info` VALUES (1,95,3,1,'作业环境安全检查','检查局部通风','1.风筒完好，吊挂平、直',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','风筒不完好未发现'),(2,95,3,1,'作业环境安全检查','检查局部通风','2.风筒出风口到工作面迎头距离合理',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','风筒出风口到工作面迎头距离不合理未发现'),(3,95,3,1,'作业环境安全检查','检查供水管路和电气装置','1.工作面供水管路完好',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','水管漏水未发现'),(4,95,3,1,'作业环境安全检查','检查供水管路和电气装置','2.电气装置无失爆现象，电源隔离开关处于断开位置，保护接地完好、可靠',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','进线喇叭嘴坏了未发现'),(5,95,3,1,'作业环境安全检查','检查供水管路和电气装置','3.各种开关布置合理，电缆吊挂标准',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','电缆破皮未发现'),(6,95,3,2,'运行装置安全检查','检查操作装置','1.紧急停机按钮等各种电气操作按钮、旋钮灵敏、可靠。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','照明开、照明关、喷雾开、喷雾关、后退报警、截割警铃、截割电机、转载机、油泵电机、截割高速、截割低速、锚杆电机、急停(操作台)、急停(侧面)、开机报警、通讯联络未操作'),(7,95,3,2,'运行装置安全检查','检查操作装置','2.各液压操作手把操作灵活、无损坏，并全部置于“0”位。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','摇臂操作手把、耙爪手把、运输机手把、截割头手把、后支撑手把、铲板手把、右行走手把、左行走手把未操作'),(8,95,3,2,'运行装置安全检查','检查操作装置','3.操作信号装置安装位置正确，能够清晰发送操作报警信号。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','掘进机启动信号未操作'),(9,95,3,2,'运行装置安全检查','检查连接装置','1.各连接件（螺栓、销、轴等）齐全、完好。',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','主要连接件不完好情况2未发现'),(10,95,3,2,'运行装置安全检查','检查连接装置','2.连接正确、牢靠。',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','主要连接件连接不牢靠未发现'),(11,95,3,2,'运行装置安全检查','检查截割装置','1.截齿、挡圈齐全、无损坏',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','截齿缺失未发现'),(12,95,3,2,'运行装置安全检查','检查截割装置','2.齿座牢固，喷嘴完好',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','齿座断裂未发现'),(13,95,3,2,'运行装置安全检查','检查传动装置','1.履带、刮板链连接牢靠、松紧适度。',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','刮板链松垮未发现'),(14,95,3,2,'运行装置安全检查','检查传动装置','2.减速器、液压缸及油管、液压管等无泄漏。',4,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','铲板液压缸密封处漏油未发现'),(15,95,3,2,'运行装置安全检查','检查喷雾装置','1.内、外喷雾装置完好。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','外喷雾装置不完好情况3未发现'),(16,95,3,2,'运行装置安全检查','检查喷雾装置','2.内喷雾工作水压不小于2Mpa。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','内喷雾工作水压小于2Mpa未发现'),(17,95,3,2,'运行装置安全检查','检查喷雾装置','3.外喷雾工作水压不小于4Mpa。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','外喷雾工作水压小于4Mpa未发现'),(18,95,3,3,'试运转安全操作','试运转准备','1.闭合远程隔离开关，给掘进机送电',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','隔离开关未操作'),(19,95,3,3,'试运转安全操作','试运转准备','2.解锁掘进机紧急停机按钮',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','急停未操作'),(20,95,3,3,'试运转安全操作','试运转准备','3.打开操作台电源开关',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','急停(侧面)未操作'),(21,95,3,3,'试运转安全操作','试运转准备','4.打开前后照明装置',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','照明开未操作'),(22,95,3,3,'试运转安全操作','试运转准备','5.发送开机警报信号',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','开机警报未操作'),(23,95,3,3,'试运转安全操作','试运转','1.启动液压油泵',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','油泵电机未操作'),(24,95,3,3,'试运转安全操作','试运转','2.启动转载机',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','转载机未操作'),(25,95,3,3,'试运转安全操作','试运转','3.启动运输机',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','运输机手把未操作'),(26,95,3,3,'试运转安全操作','试运转','4.启动耙爪（星轮）',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','耙爪手把未操作'),(27,95,3,3,'试运转安全操作','试运转','5.升起截割头到水平位置',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','摇臂操作手把未操作'),(28,95,3,3,'试运转安全操作','试运转','6.升起后支撑',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','后支撑手把未操作'),(29,95,3,3,'试运转安全操作','试运转','7.抬起铲板',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','铲板手把未操作'),(30,95,3,3,'试运转安全操作','试运转','8.启动截割电机',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','截割电机未操作'),(31,95,3,3,'试运转安全操作','试运转','9.打开喷雾装置',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','喷雾开未操作'),(32,95,3,3,'试运转安全操作','试运转','10.操纵截割头左右摆动，确认试运转状态正常',10,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','摇臂操作手把未操作'),(33,95,4,1,'开机安全操作','S1_','1.打开操作台电源开关',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','操作台电源未操作'),(34,95,4,1,'开机安全操作','S1_','2.打开前后照明装置',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','照明开未操作'),(35,95,4,1,'开机安全操作','S1_','3.发送开机联系信号',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','掘进机启动信号未操作'),(36,95,4,1,'开机安全操作','S1_','4.启动液压油泵',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','油泵电机未操作'),(37,95,4,1,'开机安全操作','S1_','5.启动转载机',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','转载机未操作'),(38,95,4,1,'开机安全操作','S1_','6.启动运输机',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','运输机手把未操作'),(39,95,4,1,'开机安全操作','S1_','7.启动耙抓（星轮）',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','耙爪手把未操作'),(40,95,4,1,'开机安全操作','S1_','8.升起截割头到水平位置',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','摇臂操作手把未操作'),(41,95,4,1,'开机安全操作','S1_','9.升起后支撑',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','后支撑手把未操作'),(42,95,4,1,'开机安全操作','S1_','10.抬起铲板',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','铲板手把未操作'),(43,95,4,1,'开机安全操作','S1_','11.打开供水阀门',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','供水阀未操作'),(44,95,4,2,'截割安全操作','S1_ ','1.发送截割警报信号',7,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','截割警铃未操作'),(45,95,4,2,'截割安全操作','S1_ ','2.运行掘进机到截割位置',7,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','运行掘进机到截割位置未操作'),(46,95,4,2,'截割安全操作','S1_ ','3.放下铲板',7,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','铲板手把未操作'),(47,95,4,2,'截割安全操作','S1_ ','4.落下后支撑',7,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','后支撑手把未操作'),(48,95,4,2,'截割安全操作','S1_ ','5.启动截割电动机',7,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','截割电机未操作'),(49,95,4,2,'截割安全操作','S1_ ','6.打开喷雾装置',7,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','喷雾开未操作'),(50,95,4,2,'截割安全操作','S1_ ','7.操纵截割头进行截割运行作业',7,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','摇臂操作手把未操作'),(51,95,4,3,'停机安全操作','停机准备','1.清理工作面浮煤、浮矸',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','清理工作面浮煤、浮矸未操作'),(52,95,4,3,'停机安全操作','停机准备','2.清空输送机与转载机中的煤、矸',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','清空输送机与转载机中的煤、未操作'),(53,95,4,3,'停机安全操作','停机准备','3.发出后退警报信号',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','后退报警未操作'),(54,95,4,3,'停机安全操作','停机准备','4.撤离后方人员',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','撤离后方人员未操作'),(55,95,4,3,'停机安全操作','停机准备','5.升平、摆正截割臂',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','摇臂操作手把未操作'),(56,95,4,3,'停机安全操作','停机准备','6.抬起铲板',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','铲板手把未操作'),(57,95,4,3,'停机安全操作','停机准备','7.升起后支撑',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','后支撑手把未操作'),(58,95,4,3,'停机安全操作','停机准备','8.后退到安全位置',8,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','后退到安全位置未操作'),(59,95,4,3,'停机安全操作','正常停机','1.停止截割头运转',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','截割电机未操作'),(60,95,4,3,'停机安全操作','正常停机','2.停止内外喷雾',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','喷雾关未操作'),(61,95,4,3,'停机安全操作','正常停机','3.停止耙爪',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','耙爪手把未操作'),(62,95,4,3,'停机安全操作','正常停机','4.停止刮板输送机',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','运输机手把未操作'),(63,95,4,3,'停机安全操作','正常停机','5.停止转载机',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','转载机未操作'),(64,95,4,3,'停机安全操作','正常停机','6.放下铲板',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','铲板手把未操作'),(65,95,4,3,'停机安全操作','正常停机','7.落下截割臂',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','摇臂操作手把未操作'),(66,95,4,3,'停机安全操作','正常停机','8.落下后支撑',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','后支撑手把未操作'),(67,95,4,3,'停机安全操作','正常停机','9.停止液压油泵',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','油泵电机未操作'),(68,95,4,3,'停机安全操作','正常停机','10.关闭操作台电源开关',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','操作台电源未操作'),(69,95,4,3,'停机安全操作','正常停机','11.取下电源开关手把',11,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','电源开关手把未操作'),(70,95,4,3,'停机安全操作','紧急停机','1.按动紧急停机按钮，停止运行',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','急停(操作台)未操作'),(71,95,4,3,'停机安全操作','紧急停机','2.处理有关紧急停机情况',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','处理有关紧急停机情况未操作'),(72,95,4,3,'停机安全操作','紧急停机','3.确认危急情况排除',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','确认危急情况排除未操作'),(73,95,4,3,'停机安全操作','紧急停机','4.解锁紧急停机按钮',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','解锁急停未操作'),(74,95,4,3,'停机安全操作','紧急停机','5.报告紧急停机情况',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','报告紧急停机情况未操作'),(75,95,4,4,'收工安全操作','S1_ ','1.断开远程电源隔离开关',8,'操作步骤每步2分, 每缺一步或一步不正确扣2分','-2','隔离开关未操作'),(76,95,4,4,'收工安全操作','S1_ ','2.清理作业现场',8,'操作步骤每步2分, 每缺一步或一步不正确扣2分','-2','清理作业现场未操作'),(77,95,4,4,'收工安全操作','S1_ ','3.填写当班作业记录',8,'操作步骤每步2分, 每缺一步或一步不正确扣2分','-2','填写当班作业记录未操作'),(78,95,4,4,'收工安全操作','S1_ ','4.进行现场交接班',8,'操作步骤每步2分, 每缺一步或一步不正确扣2分','-2','现场交接班未操作'),(79,97,3,2,'运行装置安全检查','检查操作装置','1.紧急停机按钮等各种电气操作按钮、旋钮灵敏、可靠。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','照明关、开机报警、通讯联络未操作'),(80,98,1,2,'运行装置安全检查','检查操作装置','1.紧急停机按钮等各种电气操作按钮、旋钮灵敏、可靠。',6,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','急停、复位未操作'),(81,98,2,1,'开机安全操作','启动采煤机','5.选择滚筒转向，当截割电动机即将停止转动时，缓慢挂上截割部离合器',12,'操作步骤每步2分, 每缺一步或一步不正确扣2分','-2','缓慢挂上截割部离合器(左)、缓慢挂上截割部离合器(右)未操作'),(82,98,2,3,'停机安全操作','正常停机','6.断开采煤机隔离开关',6,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','断开采煤机隔离开关未操作'),(83,98,2,4,'收工安全操作','S1_','5.关闭供水阀门',9,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','关闭供水阀门未操作'),(84,108,3,1,'作业环境安全检查','检查作业环境','2.机载甲烷断电仪或便携式甲烷检测报警仪完好、可靠，甲烷浓度不超过1.0%。',6,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','甲烷浓度不超过1.0%检查错误'),(85,108,3,2,'运行装置安全检查','检查操作装置','1.紧急停机按钮等各种电气操作按钮、旋钮灵敏、可靠。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','照明开、照明关、喷雾开、喷雾关、后退报警、截割警铃、截割电机、转载机、油泵电机、截割高速、截割低速、锚杆电机、急停(操作台)、开机报警、通讯联络未操作'),(86,108,3,2,'运行装置安全检查','检查操作装置','2.各液压操作手把操作灵活、无损坏，并全部置于“0”位。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','摇臂操作手把、耙爪手把、截割头手把、后支撑手把、铲板手把、右行走手把、左行走手把未操作'),(87,109,1,1,'作业环境安全检查','检查供水管路和电气装置','4.电源隔离开关处于断开位置，刮板输送机处于闭锁状态。',4,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','电源隔离开关未处于断开位置，刮板输送机未处于闭锁状态检查错误'),(88,109,1,2,'运行装置安全检查','检查操作装置','1.紧急停机按钮等各种电气操作按钮、旋钮灵敏、可靠。',6,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','急停、复位、破碎电机开、破碎电机关、液压电机开、液压电机关、截割电机开、截割电机关、所有电机开、所有电机关、采煤机开、采煤机关未操作'),(89,109,1,2,'运行装置安全检查','检查操作装置','2.各液压操作手把操作灵活，无损坏，并全部置于“0”位。',6,'操作内容每项2分,每缺一项或一项不正确扣2分','-2','左摇臂、顶护板、右摇臂、破碎机、右液压油填充未操作'),(90,109,1,2,'运行装置安全检查','检查喷雾装置','1.内、外喷雾装置完好。',3,'操作内容每项1分,每缺一项或一项不正确扣1分','-1','内、外喷雾装置不完好检查错误'),(91,109,1,3,'试运转安全操作','试验电动机','3.发出开机警报信号，启动电动机试运转。',4,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1',''),(92,109,2,3,'停机安全操作','紧急停机','4.解锁紧急停机按钮',5,'操作步骤每步1分, 每缺一步或一步不正确扣1分','-1','解锁紧急停机按钮未操作');
/*!40000 ALTER TABLE `t_examination_result_detail_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examination_result_info`
--

DROP TABLE IF EXISTS `t_examination_result_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_result_info` (
  `ExaminationResultID` int(11) NOT NULL AUTO_INCREMENT,
  `ExamineeID` int(11) DEFAULT NULL COMMENT '考生编号',
  `ExaminationID` int(11) DEFAULT NULL COMMENT '考试编号',
  `ExaminationSubjectIDs` varchar(10) DEFAULT NULL COMMENT '考试科目（1，2）需要根据‘，’进行拆分查询',
  `FinalScore` varchar(10) DEFAULT NULL COMMENT '最终得分',
  `FinalScore2` int(11) DEFAULT NULL,
  `ExaminationResult` varchar(10) DEFAULT NULL COMMENT '考试结果（通过/未通过）',
  `ExaminationDate` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ExaminationResultID`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COMMENT='考试成绩信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_result_info`
--

LOCK TABLES `t_examination_result_info` WRITE;
/*!40000 ALTER TABLE `t_examination_result_info` DISABLE KEYS */;
INSERT INTO `t_examination_result_info` VALUES (69,1,1,'1,2',NULL,NULL,NULL,'2018-10-16 16:40:01'),(72,1,1,'1,2',NULL,NULL,NULL,'2018-10-16 16:48:55'),(73,1,1,'1,2',NULL,NULL,NULL,'2018-10-25 19:08:37'),(74,1,2,'3,4',NULL,NULL,NULL,'2018-10-25 19:09:01'),(75,1,1,'1,2',NULL,NULL,NULL,'2018-10-25 19:09:31'),(76,2,1,'1,2',NULL,NULL,NULL,'2018-10-25 19:14:55'),(77,1,1,'1,2',NULL,NULL,NULL,'2018-10-27 08:37:15'),(78,2,1,'1,2',NULL,NULL,NULL,'2018-10-27 08:40:48'),(79,1,2,'3,4',NULL,NULL,NULL,'2018-10-27 08:44:47'),(80,2,2,'3,4',NULL,NULL,NULL,'2018-10-27 08:49:12'),(81,1,1,'1,2',NULL,NULL,NULL,'2018-10-27 10:21:23'),(82,2,2,'3,4',NULL,NULL,NULL,'2018-10-27 10:21:31'),(83,1,1,'1,2',NULL,NULL,NULL,'2018-10-27 10:21:38'),(84,2,1,'1,2',NULL,NULL,NULL,'2018-10-27 10:41:05'),(85,2,1,'1,2',NULL,NULL,NULL,'2018-10-27 10:42:08'),(86,2,2,'3,4',NULL,NULL,NULL,'2018-10-27 10:42:15'),(87,1,1,'1,2',NULL,NULL,NULL,'2018-10-27 10:47:17'),(88,2,2,'3,4',NULL,NULL,NULL,'2018-10-27 10:47:25'),(89,1,1,'1,2',NULL,NULL,NULL,'2018-10-30 08:34:22'),(90,2,1,'1,2',NULL,NULL,NULL,'2018-10-30 08:53:44'),(91,1,2,'3,4',NULL,NULL,NULL,'2018-11-01 15:53:43'),(92,1,2,'3,4',NULL,NULL,NULL,'2018-11-01 15:57:31'),(93,2,2,'3,4',NULL,NULL,NULL,'2018-11-14 10:57:42'),(94,2,2,'3,4',NULL,NULL,NULL,'2018-11-14 13:26:12'),(95,2,2,'3,4','10+0',10,'未通过','2018-11-20 10:40:47'),(96,2,2,'3,4',NULL,NULL,NULL,'2018-11-21 15:21:14'),(97,2,2,'3,4','49+50',99,'通过','2018-11-21 15:24:06'),(98,2,1,'1,2','48+46',94,'通过','2018-11-21 16:23:05'),(99,2,2,'3,4',NULL,NULL,NULL,'2018-11-21 19:43:29'),(100,2,2,'3,4',NULL,NULL,NULL,'2018-11-23 15:55:13'),(101,2,2,'3,4',NULL,NULL,NULL,'2018-11-26 19:04:13'),(102,2,2,'3,4',NULL,NULL,NULL,'2018-11-26 19:33:28'),(103,2,1,'1,2',NULL,NULL,NULL,'2018-11-26 19:38:54'),(104,2,1,'1,2',NULL,NULL,NULL,'2018-11-26 20:00:06'),(105,2,2,'3,4',NULL,NULL,NULL,'2018-11-26 22:15:39'),(106,2,2,'3,4',NULL,NULL,NULL,'2018-11-26 22:30:04'),(107,2,1,'1,2',NULL,NULL,NULL,'2018-11-26 22:36:59'),(108,2,2,'3,4','46+50',96,'通过','2018-11-26 23:06:34'),(109,1,1,'1,2','43+49',92,'通过','2018-11-26 23:15:23'),(110,2,2,'3,4',NULL,NULL,NULL,'2018-11-27 08:33:53');
/*!40000 ALTER TABLE `t_examination_result_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examination_subject_info`
--

DROP TABLE IF EXISTS `t_examination_subject_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_subject_info` (
  `ExaminationSubjectID` int(11) NOT NULL AUTO_INCREMENT COMMENT '考试科目编号',
  `ExaminationSubjectName` varchar(100) DEFAULT NULL COMMENT '考试科目名称',
  `ExaminationSubjectShortName` varchar(20) DEFAULT NULL COMMENT '考试科目简称',
  `ExaminationSubjectTime` int(11) DEFAULT NULL,
  `ExaminationSubjectScore` int(11) DEFAULT NULL,
  `PaperCompilingMode` varchar(10) DEFAULT NULL,
  `IsHasChildSubject` int(11) DEFAULT NULL COMMENT '是否包含子科目 1包含 0 不包含',
  `ExaminationID` int(11) DEFAULT NULL COMMENT '考试编号',
  PRIMARY KEY (`ExaminationSubjectID`),
  KEY `FK_ExaminationID_idx` (`ExaminationID`),
  CONSTRAINT `FK_ExaminationID` FOREIGN KEY (`ExaminationID`) REFERENCES `t_examination_info` (`ExaminationID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='考试科目信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_subject_info`
--

LOCK TABLES `t_examination_subject_info` WRITE;
/*!40000 ALTER TABLE `t_examination_subject_info` DISABLE KEYS */;
INSERT INTO `t_examination_subject_info` VALUES (1,'采煤机作业前安全检查','K1',15,50,'Compulsory',0,1),(2,'采煤机安全操作','K2',15,50,'Compulsory',0,1),(3,'掘进机作业前安全检查','K1',15,50,'Compulsory',0,2),(4,'掘进机安全操作','K2',15,50,'Compulsory',0,2),(5,'安全检查与钻机试运转安全操作','K1，必考科目',15,40,'Compulsory',0,3),(6,'探放水安全操作','K2',15,60,'Random',0,3),(7,'套管安装、封孔及注浆安全操作','K3',15,60,'Random',0,3);
/*!40000 ALTER TABLE `t_examination_subject_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examination_subject_item_detail_info`
--

DROP TABLE IF EXISTS `t_examination_subject_item_detail_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_subject_item_detail_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `ContentOrStepDetail` varchar(50) DEFAULT NULL COMMENT '详情',
  `ExaminationItemID` int(11) DEFAULT NULL COMMENT '所属项目',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COMMENT='考试科目内容详情信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_subject_item_detail_info`
--

LOCK TABLES `t_examination_subject_item_detail_info` WRITE;
/*!40000 ALTER TABLE `t_examination_subject_item_detail_info` DISABLE KEYS */;
INSERT INTO `t_examination_subject_item_detail_info` VALUES (1,'①采煤机周围无其他人员和障碍物。',1),(2,'②工作面采高合理。',1),(3,'③机载甲烷断电仪或便携式甲烷检测报警仪完好、可靠，甲烷浓度不超过 1.0％。',1),(4,'④通信联络畅通。',1),(5,'①液压支架支护稳定牢靠、接顶良好。',2),(6,'②支架间密封严实，无漏煤、漏矸现象。',2),(7,'③支架前梁护帮板紧贴煤壁。',2),(8,'①工作面供水管路完好。',3),(9,'②电气装置无“失爆”现象，保护接地完好、可靠。',3),(10,'③各种开关布置合理，电缆吊挂标准。',3),(11,'④电源隔离开关处于断开位置，刮板输送',3),(12,'①紧急停机按钮等各种电气操作按钮、旋钮灵敏、可靠。',4),(13,'②各液压操作手把操作灵活，无损坏，并全部置于“0”位。',4),(14,'③操作信号装置安装位置正确，能够清晰发送操作警报信号。',4),(15,'①牵引齿轨固定牢靠，拖缆装置完好，移动不刮卡。',5),(16,'②牵引导向滑靴、平滑靴磨损量不超过10mm。',5),(17,'③牵引装置液压油缸、油管等连接牢靠、无泄漏。',5),(18,'①各连接件（螺栓、销、轴等）齐全、完好。',6),(19,'②连接正确、牢靠。',6),(20,'①截齿、挡圈齐全、无损坏。',7),(21,'②齿座牢固，喷嘴完好。',7),(22,'①内、外喷雾装置完好。',8),(23,'②内喷雾工作水压不小于 2Mpa。',8),(24,'③外喷雾工作水压不小于 4MPa。',8),(25,'按动急停按钮、闭锁开关',9),(26,'确认开关灵活，闭锁可靠并复位。',9),(27,'复位所有开关按钮',10),(28,'置全部操作手把于“0”位',10),(29,'发出开机警报信号， 启动电动机试运转',10),(30,'确认电动机运转情况正常并复位。',10),(31,'按动牵引送电按钮',11),(32,'按动左牵右牵按钮',11),(33,'确认机身移动方向正确、齿轮与齿轨啮合状态正常并复位。',11),(34,'转动（或按动）摇臂左右调高阀组手把（或按钮）',12),(35,'确认摇臂周围环境安全',12),(36,'确认摇臂升降情况正常并复位。',12),(37,'当截割电机即将停止转动时，缓慢挂上截割部离合器',13),(38,'解除刮板输送机闭锁，发出启动输送机运转信号',13),(39,'确认采煤机周围环境安全， 启动滚筒电机',13),(40,'确认滚筒运转情况正常并复位。',13),(41,'解除刮板输送机闭锁',14),(42,'发出启动输送机联系信号',14),(43,'3、打开供水管路截止阀',14),(44,'发出采煤机开机信号。',14),(45,'闭合采煤机隔离开关',15),(46,'按动启动按钮',15),(47,'按动滚筒调高按钮，升平两滚筒',15),(48,'按动电动机停止按钮',15),(49,'选择滚筒转向， 当截割电动机即将停止转动时， 缓慢挂上截割部离合器',15),(50,'启动截割主电机',15),(51,'升起采煤机前滚筒到一定截割高度',16),(52,'落下后滚筒与底板相接',16),(53,'收起前滚筒前一组支架护帮板',16),(54,'打开牵引装置',16),(55,'打开冷却、喷雾水装置',16),(56,'驱动采煤机缓慢运行',16),(57,'操作滚筒截割作业。',16),(58,'按动牵引减速按钮，降低采煤机行走速度',17),(59,'按动牵引按钮，停止采煤机行走',17),(60,'关闭截割电机，停止截割主电机',17),(61,'断开摇臂离合器',17),(62,'关闭冷却、喷雾水装置',17),(63,'断开采煤机隔离开关。',17),(64,'按动紧急停机按钮，停止采煤机运行',18),(65,'处理有关紧急停机情况',18),(66,'确认危急情况排除',18),(67,'解锁紧急停机按钮',18),(68,'报告紧急停机情况。',18),(69,'选择采煤机停机位',19),(70,'确认停机位顶板完好、无淋水',19),(71,'落下采煤机前后滚筒',19),(72,'脱开摇臂离合器',19),(73,'关闭供水阀门',19),(74,'断开采煤机隔离开关',19),(75,'清理作业现场',19),(76,'填写当班作业记录',19),(77,'进行现场交接班。',19);
/*!40000 ALTER TABLE `t_examination_subject_item_detail_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examination_subject_item_info`
--

DROP TABLE IF EXISTS `t_examination_subject_item_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examination_subject_item_info` (
  `ExaminationItemID` int(11) NOT NULL AUTO_INCREMENT,
  `ExaminationItem` varchar(20) DEFAULT NULL COMMENT '考试项目',
  `OperationContentAndStep` varchar(100) DEFAULT NULL COMMENT '操作内容与步骤',
  `Type` varchar(10) DEFAULT NULL COMMENT 'ContentAndStep',
  `ExaminationWay` varchar(20) DEFAULT NULL COMMENT '考试方式',
  `ScoreValue` int(11) DEFAULT NULL COMMENT '分值',
  `ScoreStandard` varchar(200) DEFAULT NULL COMMENT '评分标准',
  `ExaminationSubjectID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ExaminationItemID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='考试科目内容信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examination_subject_item_info`
--

LOCK TABLES `t_examination_subject_item_info` WRITE;
/*!40000 ALTER TABLE `t_examination_subject_item_info` DISABLE KEYS */;
INSERT INTO `t_examination_subject_item_info` VALUES (1,'1.作业环境安全检查','1.检查作业环境','content','虚拟仿真操作',4,'1',1),(2,'1.作业环境安全检查','2.检查支架支护','content','虚拟仿真操作',3,'1',1),(3,'1.作业环境安全检查','3.检查供水管路和电气装置','content','虚拟仿真操作',4,'1',1),(4,'2.运行装置安全检查','1.检查操作装置','content','虚拟仿真操作',6,'2',1),(5,'2.运行装置安全检查','2.检查牵引装置','content','虚拟仿真操作',3,'1',1),(6,'2.运行装置安全检查','3.检查连接装置','content','虚拟仿真操作',2,'1',1),(7,'2.运行装置安全检查','4.检查截割装置','content','虚拟仿真操作',2,'1',1),(8,'2.运行装置安全检查','5.检查喷雾装置','content','虚拟仿真操作',3,'1',1),(9,'3.试运转安全操作','1.试验急停按钮和闭锁开关','step','虚拟仿真操作',6,'3',1),(10,'3.试运转安全操作','2.试验电动机','step','虚拟仿真操作',4,'1',1),(11,'3.试运转安全操作','3.试验牵引装置','step','虚拟仿真操作',3,'1',1),(12,'3.试运转安全操作','4.试验摇臂','step','虚拟仿真操作',6,'2',1),(13,'3.试运转安全操作','5.试验滚筒','step','虚拟仿真操作',4,'1',1),(14,'1.开机安全操作','1.启动输送机','step','虚拟仿真操作',4,'1',2),(15,'1.开机安全操作','2.启动采煤机','step','虚拟仿真操作',12,'2',2),(16,'2.截割安全操作',NULL,'step','虚拟仿真操作',14,'2',2),(17,'3.停机安全操作','1.正常停机','step','虚拟仿真操作',6,'1',2),(18,'3.停机安全操作','2.紧急停机','step','虚拟仿真操作',5,'1',2),(19,'4.收工安全操作',NULL,'step','虚拟仿真操作',9,'1',2);
/*!40000 ALTER TABLE `t_examination_subject_item_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examinee_company_info`
--

DROP TABLE IF EXISTS `t_examinee_company_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examinee_company_info` (
  `ExamineeCompanyID` int(11) NOT NULL AUTO_INCREMENT COMMENT '考生所属公司编号',
  `ExamineeCompanyName` varchar(100) DEFAULT NULL COMMENT '考生所属公司名称',
  PRIMARY KEY (`ExamineeCompanyID`),
  UNIQUE KEY `ExamineeCompanyName_UNIQUE` (`ExamineeCompanyName`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='考生所属公司信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examinee_company_info`
--

LOCK TABLES `t_examinee_company_info` WRITE;
/*!40000 ALTER TABLE `t_examinee_company_info` DISABLE KEYS */;
INSERT INTO `t_examinee_company_info` VALUES (37,'神南产业发展有限公司'),(45,'辽宁多维科技有限公司');
/*!40000 ALTER TABLE `t_examinee_company_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_examinee_info`
--

DROP TABLE IF EXISTS `t_examinee_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_examinee_info` (
  `ExamineeID` int(11) NOT NULL AUTO_INCREMENT COMMENT '考生编号',
  `ExamineeName` varchar(20) DEFAULT NULL COMMENT '考生姓名',
  `IDCardNum` varchar(20) DEFAULT NULL COMMENT '身份证号',
  `ExamineeCompanyID` int(11) DEFAULT NULL COMMENT '所属公司',
  PRIMARY KEY (`ExamineeID`),
  KEY `FK_ExamineeCompany_idx` (`ExamineeCompanyID`),
  CONSTRAINT `FK_ExamineeCompany` FOREIGN KEY (`ExamineeCompanyID`) REFERENCES `t_examinee_company_info` (`ExamineeCompanyID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='考生信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_examinee_info`
--

LOCK TABLES `t_examinee_info` WRITE;
/*!40000 ALTER TABLE `t_examinee_info` DISABLE KEYS */;
INSERT INTO `t_examinee_info` VALUES (1,'wuxin','1234',37),(2,'伍鑫','210902198706013514',37);
/*!40000 ALTER TABLE `t_examinee_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_system_info`
--

DROP TABLE IF EXISTS `t_system_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_system_info` (
  `ID` int(11) NOT NULL,
  `LastDatabaseBackupTime` datetime DEFAULT NULL COMMENT '上次数据库备份时间',
  `LastSystemLogCleanupTime` datetime DEFAULT NULL COMMENT '上次系统日志清理时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_system_info`
--

LOCK TABLES `t_system_info` WRITE;
/*!40000 ALTER TABLE `t_system_info` DISABLE KEYS */;
INSERT INTO `t_system_info` VALUES (1,'2018-11-26 19:01:38','2018-11-26 19:01:38');
/*!40000 ALTER TABLE `t_system_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user_info`
--

DROP TABLE IF EXISTS `t_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user_info` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(10) DEFAULT NULL COMMENT '用户名',
  `Password` varchar(10) DEFAULT NULL COMMENT '密码',
  `Level` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='用户信息表（主控程序登录用户）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user_info`
--

LOCK TABLES `t_user_info` WRITE;
/*!40000 ALTER TABLE `t_user_info` DISABLE KEYS */;
INSERT INTO `t_user_info` VALUES (1,'admin','admin','Admin'),(2,'user','user','Normal'),(13,'root','root','Normal');
/*!40000 ALTER TABLE `t_user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vrexaminationmaincontrolsystemdb'
--

--
-- Dumping routines for database 'vrexaminationmaincontrolsystemdb'
--
/*!50003 DROP PROCEDURE IF EXISTS `AddExaminationPCInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddExaminationPCInfo`(IN _ExamPCName VARCHAR(20), IN _IP VARCHAR(20), IN _Port VARCHAR(20), IN _Mac VARCHAR(20), IN _Type VARCHAR(20))
BEGIN

INSERT INTO t_examination_pc_info(ExamPCName, IP, Port, Mac, Type) values (_ExamPCName, _IP, _Port, _Mac, _Type);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddExaminationResultDetailInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddExaminationResultDetailInfo`(IN _ExaminationResultID VARCHAR(20), IN _ExaminationSubjectID VARCHAR(20),in _No VARCHAR(20),IN _ExaminationItem VARCHAR(20),IN _ExaminationContentAndStep_Title VARCHAR(20), IN _ExaminationContentAndStep_Detail VARCHAR(45),IN _ScoreValue VARCHAR(45),IN _EvaluationStandard VARCHAR(45), IN _DeductionCondition VARCHAR(20),IN _DeductionReason VARCHAR(200))
BEGIN

insert into t_examination_result_detail_info(ExaminationResultID,ExaminationSubjectID,No,ExaminationItem,ExaminationContentAndStep_Title,ExaminationContentAndStep_Detail,ScoreValue,EvaluationStandard,DeductionCondition,DeductionReason)values(_ExaminationResultID,_ExaminationSubjectID,_No,_ExaminationItem,_ExaminationContentAndStep_Title,_ExaminationContentAndStep_Detail,_ScoreValue,_EvaluationStandard,_DeductionCondition,_DeductionReason);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddExaminationResultInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddExaminationResultInfo`(IN _ExamineeID INT, IN _ExaminationID INT, IN _ExaminationSubjectIDs VARCHAR(20), IN _ExaminationDate datetime)
BEGIN

INSERT INTO t_examination_result_info(ExamineeID, ExaminationID, ExaminationSubjectIDs, ExaminationDate) values (_ExamineeID, _ExaminationID, _ExaminationSubjectIDs, _ExaminationDate);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddExamineeCompanyInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddExamineeCompanyInfo`(IN _ExamineeCompanyName VARCHAR(100))
BEGIN

INSERT INTO t_examinee_company_info(ExamineeCompanyName) values (_ExamineeCompanyName);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddExamineeInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddExamineeInfo`(IN _ExamineeName VARCHAR(20), IN _IDCardNum VARCHAR(20), IN _ExamineeCompanyID VARCHAR(20))
BEGIN

INSERT INTO t_examinee_info(ExamineeName, IDCardNum, ExamineeCompanyID) values (_ExamineeName, _IDCardNum, _ExamineeCompanyID);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddUserInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddUserInfo`(IN _UserName VARCHAR(20), IN _Password VARCHAR(20), IN _Level VARCHAR(20))
BEGIN

INSERT INTO t_user_info(UserName, Password, Level) values (_UserName, _Password, _Level);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DelExaminationPCInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DelExaminationPCInfo`(IN _ID INT)
BEGIN

DELETE FROM t_examination_pc_info WHERE ID = _ID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DelExaminationResultInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DelExaminationResultInfo`(IN _ExaminationResultID INT)
BEGIN
DELETE FROM t_examination_result_info WHERE ExaminationResultID = _ExaminationResultID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DelExamineeCompanyInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DelExamineeCompanyInfo`(IN _ExamineeCompanyID INT)
BEGIN

DELETE FROM t_examinee_company_info WHERE ExamineeCompanyID = _ExamineeCompanyID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DelExamineeInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DelExamineeInfo`(IN _ExamineeID INT)
BEGIN

DELETE FROM t_examinee_info WHERE ExamineeID = _ExamineeID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DelUserInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DelUserInfo`(IN _ID INT)
BEGIN

DELETE FROM t_user_info WHERE ID = _ID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllExaminationInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllExaminationInfo`()
BEGIN

select * from  t_examination_info;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllExaminationPCInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllExaminationPCInfo`()
BEGIN

SELECT * FROM t_examination_pc_info order by t_examination_pc_info.Type desc, IP;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllExaminationSubjectInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllExaminationSubjectInfo`()
BEGIN

SELECT * FROM t_examination_subject_info;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllExaminationSubjectInfoByExaminationID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllExaminationSubjectInfoByExaminationID`(IN _ExaminationID INT)
BEGIN

SELECT * FROM t_examination_subject_info WHERE ExaminationID = _ExaminationID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllExamineeCompanyInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllExamineeCompanyInfo`()
BEGIN

SELECT * FROM t_examinee_company_info;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllExamineeInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllExamineeInfo`()
BEGIN

SELECT * FROM  t_examinee_info AS A, t_examinee_company_info AS B WHERE A.ExamineeCompanyID = B.ExamineeCompanyID

ORDER BY A.ExamineeID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllSystemInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllSystemInfo`()
BEGIN

SELECT * FROM t_system_info;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllUserInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllUserInfo`()
BEGIN

SELECT * FROM t_user_info;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllUserInfoByID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllUserInfoByID`(IN _ID INT)
BEGIN

SELECT * FROM t_user_info WHERE ID = _ID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDataWithPage` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetDataWithPage`(
IN _Columns VARCHAR(100), 
IN _TableName VARCHAR(300), 
IN _Where VARCHAR(100), 
IN _OrderBy VARCHAR(100), 
IN _PageIndex INT, 
IN _PageSize INT
)
BEGIN

DECLARE _StrWhere VARCHAR(100); 
DECLARE _Strsql VARCHAR(100);
DECLARE START_ID NVARCHAR(50);
DECLARE END_ID NVARCHAR(50);

DECLARE _TotalCount INT; 
DECLARE _PageCount INT; 

SET @rowindex = 0;


IF _Where IS NOT NULL AND LENGTH(LTRIM(RTRIM(_Where))) > 0

THEN SET _StrWhere = CONCAT(' WHERE ', _Where , ' ');

ELSE SET _StrWhere = '';

END IF;

IF _PageIndex < 1 THEN SET _PageIndex = 1; END IF;

IF _PageIndex = 1 THEN


SET @_Strsql = CONCAT('SELECT ', _Columns, ' FROM ', _TableName, ' ', _StrWhere, ' ORDER BY ', _OrderBy, ' Limit 0, ', _PageSize, ';');
SET @_Strsql2 = CONCAT('SELECT ', '@rowindex:=@rowindex + 1 as rownumber', ' FROM ', _TableName, ' ', _StrWhere);

ELSE 

SET @_START_ROW = _PageSize * (_pageIndex - 1);

SET @_PAGE_SIZE = _PageSize;



SET @_Strsql = CONCAT('SELECT ', _Columns, ' FROM ', _TableName, ' ', _StrWhere, ' ORDER BY ', _OrderBy, ' Limit ', @_START_ROW , ',' , @_PAGE_SIZE, ';');
SET @_Strsql2 = CONCAT('SELECT ', '@rowindex:=@rowindex + 1 as rownumber', ' FROM ', _TableName, ' ', _StrWhere);
END IF;





prepare stmt from @_Strsql; 

EXECUTE stmt; 

deallocate prepare stmt; 

prepare stmt from @_Strsql2; 

EXECUTE stmt; 

deallocate prepare stmt; 

SET _TotalCount = @rowindex;

If (_TotalCount <= _PageSize) THEN SET _PageSize = 1;
ELSE IF (_TotalCount % _PageSize > 0 ) THEN SET _PageCount = _TotalCount / _PageSize + 1;
ELSE SET _PageCount = _TotalCount / _PageSize;
END If;
END If;

SELECT _TotalCount AS TotalCount, _PageCount AS PageCount;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExaminationInfoByExaminationID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExaminationInfoByExaminationID`(IN _ExaminationID INT)
BEGIN

SELECT * FROM t_examination_info WHERE ExaminationID = _ExaminationID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExaminationResultDetailByExaminationResultID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExaminationResultDetailByExaminationResultID`(IN _ExaminationResultID INT)
BEGIN

SELECT * FROM t_examination_result_detail_info WHERE ExaminationResultID = _ExaminationResultID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExaminationSubjectInfoByExamineeSubjectID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExaminationSubjectInfoByExamineeSubjectID`(IN _ExaminationSubjectID INT)
BEGIN

SELECT * FROM t_examination_subject_info WHERE ExaminationSubjectID = _ExaminationSubjectID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExamineeCompanyIDByExamineeCompanyName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExamineeCompanyIDByExamineeCompanyName`(IN _ExamineeCompanyName VARCHAR(50))
BEGIN

SELECT ExamineeCompanyID FROM t_examinee_company_info WHERE ExamineeCompanyName = _ExamineeCompanyName;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExamineeInfoByExamineeID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExamineeInfoByExamineeID`(IN _ExamineeID INT)
BEGIN

SELECT * FROM t_examinee_info a inner join t_examinee_company_info b on a.ExamineeCompanyID = b.ExamineeCompanyID

WHERE a.ExamineeID = _ExamineeID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExamineeInfoByIDCardNum` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExamineeInfoByIDCardNum`(IN _IDCardNum VARCHAR(20))
BEGIN
SELECT * FROM t_examinee_info a inner join t_examinee_company_info b on a.ExamineeCompanyID = b.ExamineeCompanyID

WHERE a.IDCardNum = _IDCardNum;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExamResultDetailByExamResultID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExamResultDetailByExamResultID`(IN _ExaminationResultID INT)
BEGIN

SELECT * FROM t_examination_result_detail_info a inner join t_examination_subject_info b on a.ExaminationSubjectID = b.ExaminationSubjectID

WHERE a.ExaminationResultID = _ExaminationResultID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetExamResultDetailByExamResultIDAndExamSubjectID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetExamResultDetailByExamResultIDAndExamSubjectID`(IN _ExaminationResultID INT, IN _ExaminationSubjectID INT)
BEGIN

SELECT * FROM t_examination_result_detail_info a inner join t_examination_subject_info b on a.ExaminationSubjectID = b.ExaminationSubjectID 

WHERE a.ExaminationResultID = _ExaminationResultID AND a.ExaminationSubjectID = _ExaminationSubjectID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetLastExaminationResultID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetLastExaminationResultID`()
BEGIN

SELECT MAX(ExaminationResultID) FROM  t_examination_result_info ORDER BY ExaminationResultID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetLastExamineeID` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetLastExamineeID`()
BEGIN

SELECT MAX(ExamineeID) FROM  t_examinee_info ORDER BY ExamineeID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetUserLevelByUserName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetUserLevelByUserName`(IN _UserName VARCHAR(20))
BEGIN

SELECT Level FROM t_user_info WHERE UserName = _UserName;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `IsUserExist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `IsUserExist`(IN _UserName VARCHAR(20), IN _Password VARCHAR(20))
BEGIN

SELECT COUNT(*) FROM t_user_info WHERE UserName = _UserName AND Password = _Password;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `IsUserNameExist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `IsUserNameExist`(IN _UserName VARCHAR(20))
BEGIN

SELECT COUNT(*) FROM t_user_info WHERE UserName = _UserName;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdExaminationPCInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdExaminationPCInfo`(IN _ID INT, IN _ExamPCName VARCHAR(20), IN _IP VARCHAR(20), IN _Port VARCHAR(20), IN _Mac VARCHAR(20), IN _Type VARCHAR(20))
BEGIN

UPDATE t_examination_pc_info SET ExamPCName = _ExamPCName, IP = _IP, Port = _Port, Mac = _Mac, Type = _Type WHERE ID = _ID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdExaminationResultInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdExaminationResultInfo`(IN _FinalScore VARCHAR(20), IN _FinalScore2 VARCHAR(20), IN _ExaminationResult VARCHAR(20),IN _ExaminationResultID VARCHAR(20))
BEGIN
UPDATE t_examination_result_info SET FinalScore = _FinalScore, FinalScore2 = _FinalScore2,ExaminationResult=_ExaminationResult WHERE ExaminationResultID = _ExaminationResultID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdExamineeCompanyInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdExamineeCompanyInfo`(IN _ExamineeCompanyID INT, IN _ExamineeCompanyName VARCHAR(100))
BEGIN

UPDATE t_examinee_company_info SET ExamineeCompanyName = _ExamineeCompanyName WHERE ExamineeCompanyID = _ExamineeCompanyID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdExamineeInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdExamineeInfo`(IN _ExamineeName VARCHAR(20), IN _IDCardNum VARCHAR(20), IN _ExamineeCompanyID INT, IN _ExamineeID INT)
BEGIN

UPDATE t_examinee_info SET ExamineeName = _ExamineeName, IDCardNum = _IDCardNum, ExamineeCompanyID = _ExamineeCompanyID WHERE ExamineeID = _ExamineeID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdSystemInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdSystemInfo`(IN _ID INT, IN _LastDatabaseBackupTime datetime, IN _LastSystemLogCleanupTime datetime)
BEGIN

UPDATE t_system_info SET LastDatabaseBackupTime = _LastDatabaseBackupTime, LastSystemLogCleanupTime = _LastSystemLogCleanupTime WHERE ID = _ID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdUserInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdUserInfo`(IN _ID INT, IN _UserName VARCHAR(20), IN _Password VARCHAR(20))
BEGIN

UPDATE t_user_info SET UserName = _UserName, Password = _Password WHERE ID = _ID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-27  8:36:40
